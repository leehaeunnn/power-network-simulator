class Building:
    def __init__(self, idx, base_supply=0.0, name=None):
        self.idx=idx
        self.name = name if name else f"건물_{idx}" # 이름 속성 추가
        self.base_supply=base_supply  # 기본 공급량 (음수=수요)
        self.solar_capacity=0.0       # 태양광 설치 용량
        self.current_supply=base_supply
        self.transmitted_power=0.0    # 실제 송전량 추적
        self.x=0
        self.y=0
        self.removed=False
        self.blackout=False
        self.is_prosumer=False        # 프로슈머 여부
        
        # 추가 속성들
        self.building_type = "apartment"    # 건물 유형: apartment, office, school, hospital, shopping_mall
        self.energy_efficiency = 1.0        # 에너지 효율 (1.0 = 기본, 낮을수록 효율 높음)
        self.year_built = 2010              # 건설 연도
        self.area = 1000                    # 건물 면적 (제곱미터)
        self.heating_source = "electric"    # 난방 방식: electric, gas, district
        self.heating_type = "electric"      # 난방 유형: electric, heat_pump, gas
        self.heating_cop = 1.0              # 난방 COP (히트펌프 용)
        self.humidity_sensitivity = 1.0     # 습도에 대한 민감도
        self.panel_tilt = 30                # 태양광 패널 경사각 (도)
        self.panel_azimuth = 180            # 태양광 패널 방위각 (도, 남쪽=180)
        self.smart_grid_connected = False   # 스마트 그리드 연결 여부
        self.battery_capacity = 0.0         # 배터리 저장 용량
        self.battery_charge = 0.0           # 현재 배터리 충전량
        self.shortage = 0.0                 # 현재 부족 전력량 (check_blackouts에서 계산)

    def get_type_str(self):
        if self.base_supply > 0 and not self.is_prosumer: # 순수 발전소
            # building_type이 "producer"가 아닌 다른 구체적인 발전소 종류일 수도 있음
            return self.building_type if self.building_type not in ["consumer", "neutral", "prosumer", "apartment", "office", "school", "hospital", "shopping_mall"] else "발전소"

        if self.is_prosumer:
            # 프로슈머의 경우, 구체적인 건물 유형과 결합 가능
            type_detail = ""
            if self.building_type not in ["producer", "consumer", "neutral", "prosumer"]:
                 type_detail = f" ({self.building_type})"
            return f"프로슈머{type_detail}"

        if self.solar_capacity > 0: # 태양광 시설이 있고 프로슈머가 아닌 경우
            if self.base_supply < 0: # 태양광 + 수요 (예: 태양광 아파트)
                type_prefix = "태양광 "
                base_type = self.building_type
                if self.building_type in ["producer", "consumer", "neutral", "prosumer"]:
                    base_type = "소비시설" # 역할 기반 타입이 오면 일반적인 용어로
                return f"{type_prefix}{base_type}"
            else: # 태양광만 (base_supply == 0)
                type_prefix = "태양광 "
                base_type = self.building_type
                if self.building_type in ["producer", "consumer", "neutral", "prosumer"]:
                    base_type = "발전시설" # 역할 기반 타입이 오면 일반적인 용어로
                return f"{type_prefix}{base_type}"

        if self.base_supply < 0: # 순수 수요 건물
            # building_type이 역할 기반이면 "소비시설"로, 아니면 building_type 그대로
            return self.building_type if self.building_type not in ["producer", "neutral", "prosumer"] else "소비시설"
            
        # base_supply == 0, solar_capacity == 0, is_prosumer == False
        if self.building_type == "neutral":
            return "중립시설"
        
        # 위 모든 경우에 해당하지 않으면 기본값 또는 building_type 그대로 반환
        # "apartment" 등이 이미 위에서 처리되었을 수 있으므로, 남은 경우는 기본값으로 처리
        if self.building_type not in ["producer", "consumer", "neutral", "prosumer", "apartment", "office", "school", "hospital", "shopping_mall"]:
            return "일반건물" # 혹은 그냥 self.building_type
        
        return self.building_type # 시나리오에 명시된 building_type (apartment 등) 반환

    def get_status_str(self):
        status = []
        if self.base_supply > 0:  # 발전소인 경우
            status.append(f"발전: {self.base_supply:+.1f}")
            status.append(f"출력: {self.transmitted_power:+.1f}")
        elif self.base_supply != 0:
            status.append(f"기본: {self.base_supply:+.1f}")
            
            # 추가 정보: 에너지 효율
            efficiency_str = "상" if self.energy_efficiency < 0.8 else "중" if self.energy_efficiency < 1.2 else "하"
            status.append(f"효율: {efficiency_str}")
            
        if self.solar_capacity > 0:
            status.append(f"태양광: {self.solar_capacity:+.1f}")
            status.append(f"각도: {self.panel_tilt}°")
        
        if self.current_supply != self.base_supply:
            status.append(f"현재: {self.current_supply:+.1f}")
        
        if self.battery_capacity > 0:
            charge_percent = (self.battery_charge / self.battery_capacity) * 100
            status.append(f"배터리: {charge_percent:.0f}%")
            
        if self.blackout:
            status.append("정전!")
            
        # 난방 정보 표시
        if self.heating_source != "electric":
            status.append(f"난방: {self.heating_source}")
            
        # 스마트 그리드 연결 정보
        if self.smart_grid_connected:
            status.append("스마트그리드")
            
        return ", ".join(status)
        
    def get_detailed_info(self):
        """
        건물에 대한 상세 정보를 반환 (툴팁 표시용)
        """
        info = []
        info.append(f"ID: {self.idx}")
        info.append(f"유형: {self.get_type_str()}")
        
        if self.base_supply > 0:  # 발전소
            info.append(f"기본 발전량: {self.base_supply:.1f}")
            info.append(f"현재 발전량: {self.current_supply:.1f}")
            info.append(f"실제 송전량: {self.transmitted_power:.1f}")
        else:
            info.append(f"기본 수요: {-self.base_supply:.1f}")
            info.append(f"현재 수요: {-self.current_supply:.1f}")
            
        if self.solar_capacity > 0:
            info.append(f"태양광 용량: {self.solar_capacity:.1f}")
            info.append(f"패널 경사각: {self.panel_tilt}°")
            info.append(f"패널 방위각: {self.panel_azimuth}°")
            
        info.append(f"건설 연도: {self.year_built}")
        info.append(f"건물 면적: {self.area}㎡")
        
        if self.heating_source != "electric":
            info.append(f"난방 방식: {self.heating_source}")
            
        if self.heating_type == "heat_pump":
            info.append(f"난방 COP: {self.heating_cop:.1f}")
            
        if self.battery_capacity > 0:
            info.append(f"배터리 용량: {self.battery_capacity:.1f}")
            info.append(f"현재 충전량: {self.battery_charge:.1f} ({(self.battery_charge/self.battery_capacity)*100:.0f}%)")
            
        if self.smart_grid_connected:
            info.append("스마트 그리드 연결됨")
            
        if self.blackout:
            info.append("⚠️ 정전 상태")
            
        return info

class PowerLine:
    def __init__(self, u,v,capacity=5.0,cost=1.0):
        self.u=u
        self.v=v
        self.capacity=capacity
        self.cost=cost
        self.flow=0.0
        self.removed=False

class CityGraph:
    def __init__(self):
        self.buildings=[]
        self.lines=[]
        self.n=0

    def clear_all(self):
        """모든 건물과 송전선을 제거하고 초기화합니다."""
        self.buildings = []
        self.lines = []
        self.n = 0
        print("[CityGraph] 모든 데이터가 초기화되었습니다.")

    def add_building(self, base_supply=0.0,x=0,y=0, building_type="apartment", name=None, solar_capacity=0.0, is_prosumer=False):
        # 이름이 명시적으로 주어지지 않으면 기본 이름 사용
        actual_name = name if name else f"{building_type}_{self.n}"
        b=Building(self.n, base_supply, name=actual_name)
        b.x,b.y=x,y
        self.buildings.append(b)
        self.n+=1
        return b

    def add_line(self,u,v,cap=5.0,cost=1.0):
        # Check if the indices are valid before creating the line
        if u < 0 or u >= self.n or v < 0 or v >= self.n:
            print(f"Warning: Invalid building indices ({u}, {v}) in add_line. Buildings range is 0-{self.n-1}")
            return None
        if self.buildings[u].removed or self.buildings[v].removed:
            print(f"Warning: Cannot add line between removed buildings ({u}, {v})")
            return None
        
        pl=PowerLine(u,v,cap,cost)
        self.lines.append(pl)
        return pl  # 생성된 PowerLine 객체 반환

    def total_demand(self):
        return sum(-b.current_supply for b in self.buildings if b.current_supply<0 and not b.removed)



    ###############################################################################
    # (B) Building, PowerLine, CityGraph 내 build_capacity 함수 (수정본)
    ###############################################################################
    def build_capacity(self):
        """
        CityGraph 클래스 내에 삽입되는 메서드. 
        'self'는 CityGraph 인스턴스.
        """

        print("[build_capacity] 호출됨 - 그래프 용량 구성 시작 --------------------------------")
        S_star = self.n        # 슈퍼소스
        T_star = self.n + 1    # 슈퍼싱크
        n_total = self.n + 2   # 전체 노드(빌딩 n개 + S*, T*)

        # 각 노드별로 (연결노드->capacity) 를 저장할 dict
        cap = [dict() for _ in range(n_total)]

        # 먼저, 송전선 용량 설정
        print("  [build_capacity] 송전선(capacity) 설정 중...")
        for pl in self.lines:
            if pl.removed:
                continue
            if self.buildings[pl.u].removed or self.buildings[pl.v].removed:
                continue
            if pl.capacity > 1e-9:
                # u->v 방향 capacity 지정
                cap[pl.u][pl.v] = pl.capacity
                print(f"    선({pl.u}->{pl.v}), capacity={pl.capacity:.2f}")

        # 각 발전소의 실제 공급 가능량 계산 (연결된 송전선 용량의 합으로 제한)
        print("  [build_capacity] 발전소별 실제 공급 가능량 계산 중...")
        building_max_supply = {}
        for b in self.buildings:
            if b.removed:
                continue
            if b.current_supply > 1e-9:  # 발전소인 경우 (current_supply 기준)
                total_line_capacity = 0
                for pl in self.lines:
                    if pl.removed:
                        continue
                    if self.buildings[pl.u].removed or self.buildings[pl.v].removed:
                        continue
                    if pl.u == b.idx:  # 발전소에서 나가는 선
                        total_line_capacity += pl.capacity
                # 실제 공급 가능량은 current_supply와 송전선 총 용량 중 작은 값
                building_max_supply[b.idx] = min(b.current_supply, total_line_capacity)
                print(f"    발전소{b.idx}: current_supply={b.current_supply:.2f}, 송전선총용량={total_line_capacity:.2f}, 실제가능량={building_max_supply[b.idx]:.2f}")

        # 발전소(양수 current_supply)와 슈퍼소스(S_star) 연결
        print("  [build_capacity] 발전소/수요지 연결 설정 중...")
        for b in self.buildings:
            if b.removed:
                continue
            idx = b.idx
            # 공급 건물 (current_supply 기준)
            if b.current_supply > 1e-9:
                # S_star -> b.idx (실제 공급 가능량으로 제한)
                # building_max_supply 딕셔너리에서 값을 가져오고, 없으면 b.current_supply 사용 (이론적으로는 항상 있어야 함)
                max_supply = building_max_supply.get(idx, b.current_supply) 
                cap[S_star][idx] = max_supply
                print(f"    슈퍼소스 -> {idx}, supply={max_supply:.2f} (current_supply 기반)")

            # 수요 건물(음수)
            elif b.current_supply < -1e-9:
                # b.idx -> T_star
                demand_val = -b.current_supply
                cap[idx][T_star] = demand_val
                print(f"    {idx} -> 슈퍼싱크, demand={demand_val:.2f} (current_supply 기반)")

        print("[build_capacity] 그래프 용량 구성 완료 -----------------------------------------\n")
        return cap, S_star, T_star



    def restore_all(self):
        for b in self.buildings:
            b.removed=False
        for pl in self.lines:
            pl.removed=False
