import pygame
import math
from utils import *
from data import *
from algorithms import analyze_current_grid_status

class DrawerRenderer:
    def __init__(self, drawer):
        self.drawer = drawer  # Drawer 인스턴스 참조
        self.simulator = drawer.simulator  # 시뮬레이터 참조
        self.screen = drawer.screen  # pygame 화면
        self.width = drawer.width
        self.height = drawer.height
        
        # 폰트 참조
        self.font = drawer.font
        self.big_font = drawer.big_font
        self.small_font = drawer.small_font
        self.scenario_name_font = drawer.scenario_name_font
    
    def _truncate_text(self, text, font, max_width):
        if font.size(text)[0] <= max_width:
            return text
        else:
            truncated_text = ""
            # "..."의 너비를 미리 계산
            ellipsis_width = font.size("...")[0]
            current_width = 0
            for char in text:
                char_width = font.size(char)[0]
                if current_width + char_width + ellipsis_width > max_width:
                    break
                truncated_text += char
                current_width += char_width
            return truncated_text + "..."
    
    def draw_frame(self, partial=False):
        """전체 화면 그리기"""
        # 배경
        draw_city_background(self.screen, self.width, self.height)
        
        # 임시 송전선 그리기 (송전선 추가 모드)
        self._draw_temp_line()
        
        # 송전선 그리기
        self._draw_power_lines()
        
        # 파티클 그리기
        self.drawer.particles.draw(self.screen, self.drawer)
        
        # 건물 그리기
        for b in self.simulator.city.buildings:
            if b.removed:
                continue
            self.draw_building(b)
        
        # UI 패널 그리기
        self._draw_ui_panel()
        
        # 전력 공급 상황 표시
        self._draw_power_status()
        
        # 모드 및 예산 정보 표시
        self._draw_mode_info()
        
        # 시간/날씨 표시
        self._draw_time_weather()
        
        if not partial:
            if self.drawer.show_help:
                self.draw_help_overlay()
            if self.drawer.show_scenario_list:
                self.draw_scenario_list()
            if hasattr(self.drawer, 'show_ai_upgrade_panel') and self.drawer.show_ai_upgrade_panel:
                self.draw_ai_upgrade_panel()
            self.draw_tooltip()
            self.drawer.context_menu.draw(self.screen)

    def _draw_temp_line(self):
        """송전선 추가 모드에서 임시 선 그리기"""
        if self.drawer.add_mode == "add_line" and self.drawer.temp_line_start:
            mx, my = pygame.mouse.get_pos()
            start_x, start_y = self.drawer.world_to_screen(self.drawer.temp_line_start.x, self.drawer.temp_line_start.y)
            dash_length = 10
            space_length = 5
            total_length = math.hypot(mx-start_x, my-start_y)
            angle = math.atan2(my-start_y, mx-start_x)
            dash_count = int(total_length / (dash_length + space_length))
            for i in range(dash_count):
                start_dist = i * (dash_length + space_length)
                end_dist = start_dist + dash_length
                if end_dist > total_length:
                    end_dist = total_length
                dash_start_x = start_x + math.cos(angle) * start_dist
                dash_start_y = start_y + math.sin(angle) * start_dist
                dash_end_x = start_x + math.cos(angle) * end_dist
                dash_end_y = start_y + math.sin(angle) * end_dist
                pygame.draw.line(self.screen, (255, 255, 100),
                               (dash_start_x, dash_start_y),
                               (dash_end_x, dash_end_y), 2)

    def _draw_power_lines(self):
        """송전선 그리기"""
        for pl in self.simulator.city.lines:
            if pl.removed:
                continue
            if self.simulator.city.buildings[pl.u].removed or self.simulator.city.buildings[pl.v].removed:
                continue
                
            # 시작점과 끝점 건물 좌표 가져오기
            x1 = self.simulator.city.buildings[pl.u].x
            y1 = self.simulator.city.buildings[pl.u].y
            x2 = self.simulator.city.buildings[pl.v].x
            y2 = self.simulator.city.buildings[pl.v].y
            sx1, sy1 = self.drawer.world_to_screen(x1, y1)
            sx2, sy2 = self.drawer.world_to_screen(x2, y2)
            
            # 사용률에 따른 색상 계산
            usage = 0
            if pl.capacity > 1e-9:
                usage = abs(pl.flow) / pl.capacity
                if usage > 1:
                    usage = 1
            r = int(200 * usage)
            g = int(200 * (1 - usage))
            color = (r, g, 0)
            thick = max(3, int(3 + 7 * usage))
            
            # 파티클 생성
            if abs(pl.flow) > 0.1:  # 의미있는 전력 흐름이 있을 때만
                b_start = self.simulator.city.buildings[pl.u]
                b_end = self.simulator.city.buildings[pl.v]
                self.drawer.particles.spawn_particles_for_line(pl, b_start, b_end, self.drawer.clock.get_time())
            
            # 글로우 효과
            if usage > 0.2:
                glow_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
                glow_col = (r, g, 0, 80)
                pygame.draw.line(glow_surf, glow_col, (sx1, sy1), (sx2, sy2), thick + 8)
                self.screen.blit(glow_surf, (0, 0))
            
            # 메인 라인
            pygame.draw.line(self.screen, color, (sx1, sy1), (sx2, sy2), thick)
            if abs(pl.flow) > 0.1:
                if pl.flow > 0:
                    draw_arrow(self.screen, sx1, sy1, sx2, sy2, color, thick)
                else:
                    draw_arrow(self.screen, sx2, sy2, sx1, sy1, color, thick)
            
            # 중간 정보 박스 그리기
            self._draw_line_info(pl, sx1, sy1, sx2, sy2, usage)
    
    def _draw_line_info(self, pl, sx1, sy1, sx2, sy2, usage):
        """송전선 중앙에 정보 박스 그리기"""
        mid_x = (sx1 + sx2) / 2
        mid_y = (sy1 + sy2) / 2
        info_color = (0, 200, 0) if usage < 0.5 else (200, 200, 0) if usage < 0.8 else (200, 0, 0)
        usage_percent = usage * 100
        flow_text = f"{abs(pl.flow):.1f}/{pl.capacity:.1f}"
        usage_text = f"{usage_percent:.0f}%"
        if usage > 0.8:
            warning = "⚠" if usage > 0.95 else "!"
            flow_text = warning + " " + flow_text
        
        # 텍스트 렌더링 함수
        def render_text_with_shadow(text, color):
            shadow_surf = self.small_font.render(text, True, (0, 0, 0))
            text_surf = self.small_font.render(text, True, color)
            combined = pygame.Surface((text_surf.get_width() + 2, text_surf.get_height() + 2), pygame.SRCALPHA)
            combined.blit(shadow_surf, (2, 2))
            combined.blit(text_surf, (0, 0))
            return combined
        
        flow_surf = render_text_with_shadow(flow_text, info_color)
        usage_surf = render_text_with_shadow(usage_text, info_color)
        
        # 박스 크기 및 위치 계산
        padding = 4
        margin = 2
        box_width = max(flow_surf.get_width(), usage_surf.get_width()) + padding * 2
        box_height = flow_surf.get_height() + usage_surf.get_height() + padding * 2 + margin
        box = pygame.Surface((box_width, box_height), pygame.SRCALPHA)
        box.fill((0, 0, 0, 160))
        
        # 텍스트 배치
        flow_x = (box_width - flow_surf.get_width()) / 2
        usage_x = (box_width - usage_surf.get_width()) / 2
        box.blit(flow_surf, (flow_x, padding))
        box.blit(usage_surf, (usage_x, padding + flow_surf.get_height() + margin))
        
        # 박스 위치 조정 (화면 경계 넘지 않도록)
        box_x = mid_x - box_width / 2
        box_y = mid_y - box_height / 2
        if box_x < 0: box_x = 0
        if box_y < 0: box_y = 0
        if box_x + box_width > self.width: box_x = self.width - box_width
        if box_y + box_height > self.height: box_y = self.height - box_height
        
        # 화면에 그리기
        self.screen.blit(box, (box_x, box_y))

    def draw_building(self, b):
        """건물 그리기"""
        sx, sy = self.drawer.world_to_screen(b.x, b.y)
        base_r = 25
        size_factor = min(2.0, max(0.8, 1.0 + abs(b.current_supply) / 10.0))
        r = base_r * size_factor
        
        # 송전선 추가/삭제 모드에서 glow 효과
        self._draw_building_mode_effects(b, sx, sy, r)
        
        # 그림자 그리기
        shadow_col = (0, 0, 0, 60)
        sh_off = 4
        shadow_surf = pygame.Surface((r * 2 + 8, r * 2 + 8), pygame.SRCALPHA)
        pygame.draw.circle(shadow_surf, shadow_col, (r + 4, r + 4), r + 3)
        self.screen.blit(shadow_surf, (sx - (r + 4), sy - (r + 4)))
        
        # 건물 색상 결정
        col, border_col = self._get_building_colors(b)
        
        # 건물 종류에 따라 다른 모양 그리기
        if b.base_supply > 0:
            # 발전소 - 번개 모양
            self._draw_generator_shape(b, sx, sy, r, col, border_col)
        else:
            # 소비 건물 - 집 모양
            self._draw_consumer_shape(b, sx, sy, r, col, border_col)
        
        # 정보박스(건물 이름/수요/공급 등)
        self._draw_building_info(b, sx, sy, r)
    
    def _draw_building_mode_effects(self, b, sx, sy, r):
        """모드에 따른 건물 효과 그리기"""
        if self.drawer.add_mode == "add_line":
            glow_size = r + 8
            glow_color = (255, 255, 100, 100)
            if self.drawer.temp_line_start is None:
                glow_surf = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow_surf, glow_color, (glow_size, glow_size), glow_size)
                self.screen.blit(glow_surf, (sx - glow_size, sy - glow_size))
            elif b != self.drawer.temp_line_start:
                glow_surf = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow_surf, glow_color, (glow_size, glow_size), glow_size)
                self.screen.blit(glow_surf, (sx - glow_size, sy - glow_size))
        elif self.drawer.add_mode == "delete":
            glow_size = r + 8
            glow_color = (255, 100, 100, 100)
            glow_surf = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, glow_color, (glow_size, glow_size), glow_size)
            self.screen.blit(glow_surf, (sx - glow_size, sy - glow_size))
    
    def _get_building_colors(self, b):
        """건물 상태에 따른 색상 결정"""
        if b.base_supply > 0:
            # 발전소
            col = (100, 150, 255)
            border_col = (100, 200, 255)
        elif b.base_supply < 0:
            # 수요 건물
            if b.blackout: # b.blackout은 현재 수요 기준으로 check_blackouts에서 이미 계산됨
                # 정전된 건물은 깜빡임
                if (pygame.time.get_ticks() // 500) % 2:
                    col = (255, 100, 100) # 밝은 빨강
                    border_col = (255, 150, 150)
                else:
                    col = (200, 50, 50) # 어두운 빨강
                    border_col = (255, 100, 100)
            else:
                # 정상 작동 수요 건물 (b.shortage가 0에 가까움)
                col = (100, 200, 100) # 녹색 계열
                border_col = (150, 255, 150)
                # 만약 b.shortage 값에 따라 미세한 색상 변화를 주고 싶다면 추가 가능
                # 예를 들어, b.shortage가 현재수요 대비 특정 % 이상이면 노란색 계열 등으로...
                # current_demand = -b.current_supply if b.current_supply < 0 else 0
                # if current_demand > 1e-9 and hasattr(b, 'shortage') and b.shortage > 0:
                #    shortage_ratio_for_color = b.shortage / current_demand
                #    if shortage_ratio_for_color > 0.05: # 예: 5% 이상 부족하면 노란색
                #        col = (200, 200, 100)
                #        border_col = (255, 255, 150)

        elif b.solar_capacity > 0: # 중립적이면서 태양광이 있는 경우 (프로슈머 등)
            if b.is_prosumer:
                col = (150, 200, 50) # 프로슈머 색상
                border_col = (200, 255, 100)
            else:
                col = (200, 200, 50) # 일반 태양광 건물 색상
                border_col = (255, 255, 100)
        else:
            # 중립 건물 (수요도 공급도 아닌 경우, 예: base_supply = 0이고 태양광도 없는 경우)
            col = (150, 150, 150)
            border_col = (200, 200, 200)
        
        return col, border_col
    
    def _draw_generator_shape(self, b, sx, sy, r, col, border_col):
        """발전소 모양 그리기 (번개 모양)"""
        points = [
            (sx - r * 0.2, sy - r * 0.6),
            (sx + r * 0.1, sy - r * 0.1),
            (sx - r * 0.1, sy - r * 0.1),
            (sx + r * 0.2, sy + r * 0.6),
            (sx - r * 0.1, sy + r * 0.2),
            (sx + r * 0.1, sy + r * 0.2)
        ]
        pygame.draw.polygon(self.screen, col, points)
        pygame.draw.polygon(self.screen, border_col, points, 3)
    
    def _draw_consumer_shape(self, b, sx, sy, r, col, border_col):
        """소비 건물 모양 그리기 (집 모양)"""
        house_w = r
        house_h = r
        roof_pts = [
            (sx, sy - r),
            (sx - house_w * 0.6, sy - r * 0.3),
            (sx + house_w * 0.6, sy - r * 0.3)
        ]
        pygame.draw.polygon(self.screen, col, roof_pts)
        pygame.draw.rect(self.screen, col, (sx - house_w * 0.5, sy - r * 0.3, house_w, house_h * 0.6))
        pygame.draw.polygon(self.screen, border_col, roof_pts, 3)
        pygame.draw.rect(self.screen, border_col, (sx - house_w * 0.5, sy - r * 0.3, house_w, house_h * 0.6), 3)
        
        # 태양광 패널 그리기
        if b.solar_capacity > 0:
            panel_h = r * 0.15
            panel_y = sy - r + panel_h
            pygame.draw.rect(self.screen, (0, 0, 0), (sx - house_w * 0.5, panel_y, house_w, panel_h))
            for i in range(3):
                x = sx - house_w * 0.4 + i * house_w * 0.3
                pygame.draw.rect(self.screen, (0, 150, 255), (x, panel_y, house_w * 0.25, panel_h))
    
    def _draw_building_info(self, b, sx, sy, r):
        """건물 정보 박스 그리기 (수정 최종안)"""
        type_txt = f"{b.get_type_str()}{b.idx}"
        status_lines = []

        # 소비자 정보 처리 (b.base_supply < 0)
        if b.base_supply < 0:
            base_demand = abs(b.base_supply) # 초기 설정된 기본 수요량
            current_demand = -b.current_supply if b.current_supply < 0 else 0 # 현재 실제 수요량

            status_lines.append(f"기본수요: {base_demand:.1f}") # "평균수요" -> "기본수요"로 레이블 변경
            status_lines.append(f"현재수요: {current_demand:.1f}") # 실시간 현재 수요 표시

            # 태양광 설비 정보 (있으면 표시)
            if b.solar_capacity > 0:
                status_lines.append(f"태양광설비: {b.solar_capacity:.1f}")

            # 부족 정보: 오직 b.shortage 값만 사용!
            if hasattr(b, 'shortage'):
                # 부족 라인 추가 (0.0도 표시되도록)
                status_lines.append(f"부족: {b.shortage:.1f}")

                # 부족률은 shortage가 0보다 클 때만 의미있게 표시
                # 부족률 계산 시 기준은 '현재수요'가 되어야 함
                if b.shortage > 1e-9 and current_demand > 1e-9:
                    shortage_ratio = (b.shortage / current_demand) * 100
                    status_lines.append(f"부족률: {shortage_ratio:.1f}%")
                elif current_demand <= 1e-9: # 현재 수요가 0이면 부족률 계산 불가
                    status_lines.append(f"부족률: -")
                # else: shortage가 0이면 부족률 라인 불필요 (이미 부족: 0.0 표시됨)
            else:
                status_lines.append(f"부족: N/A") # shortage 속성이 없는 경우

        # 생산자 정보 처리 (b.base_supply > 0)
        elif b.base_supply > 0:
            status_lines.append(f"발전: {b.base_supply:.1f}")
            if hasattr(b, 'current_supply') and abs(b.current_supply - b.base_supply) > 1e-9 :
                status_lines.append(f"현재출력: {b.current_supply:.1f}")

            # 송전량 정보: 오직 b.transmitted_power 값만 사용!
            if hasattr(b, 'transmitted_power'):
                 status_lines.append(f"송전량: {b.transmitted_power:.1f}")
            else:
                 status_lines.append(f"송전량: N/A")

        # 중립 건물 등 나머지 경우 처리
        else: # base_supply == 0
            status_lines.append(f"타입: {b.get_type_str()}")
            if b.solar_capacity > 0:
                status_lines.append(f"태양광: {b.solar_capacity:.1f}")
            if hasattr(b, 'current_supply') and abs(b.current_supply) > 1e-9:
                 status_lines.append(f"현재출력: {b.current_supply:.1f}")
            if hasattr(b, 'transmitted_power'):
                 # 중립 건물 등도 송전 가능성이 있으므로 표시
                 status_lines.append(f"송전량: {b.transmitted_power:.1f}")

        # 배터리 정보
        if b.battery_capacity > 0:
            charge_percent = 0
            if b.battery_capacity > 1e-9:
                charge_percent = (b.battery_charge / b.battery_capacity) * 100
            status_lines.append(f"배터리: {b.battery_charge:.1f}/{b.battery_capacity:.1f} ({charge_percent:.0f}%)")

        # 정전 정보
        if b.blackout:
            status_lines.append("정전!")

        # 텍스트 렌더링 함수
        def render_text_with_outline(text, font, color):
            shadow_surfaces = []
            outline_color = (0, 0, 0, 220)
            for dx, dy in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
                s = font.render(text, True, outline_color)
                shadow_surfaces.append((s, (dx, dy)))
            text_surface = font.render(text, True, color)
            final_surface = pygame.Surface((text_surface.get_width() + 4, text_surface.get_height() + 4), pygame.SRCALPHA)
            for surf, (dx, dy) in shadow_surfaces:
                final_surface.blit(surf, (dx + 2, dy + 2))
            final_surface.blit(text_surface, (2, 2))
            return final_surface

        # 텍스트 서피스 생성
        col, _ = self._get_building_colors(b)
        name_surf = render_text_with_outline(type_txt, self.small_font, col)
        status_surfs = [render_text_with_outline(line, self.small_font, col) for line in status_lines]

        # 박스 크기 및 위치 계산
        box_width = max([name_surf.get_width()] + [s.get_width() for s in status_surfs] if status_surfs else [name_surf.get_width()]) + 16
        current_font_height = self.small_font.get_height()
        line_spacing = 4
        box_height = name_surf.get_height() + 8
        if status_surfs:
            box_height += (len(status_surfs) * current_font_height) + ((len(status_surfs) -1) * line_spacing) + 4

        # 박스 위치 조정
        box_x = sx + r + 8
        box_y = sy - box_height // 2
        if box_x + box_width > self.width:
            box_x = sx - box_width - r - 8
        if box_y + box_height > self.height:
            box_y = self.height - box_height - 4
        if box_y < 4:
            box_y = 4

        # 정보 박스 그리기
        info_box = pygame.Surface((box_width, box_height), pygame.SRCALPHA)
        info_box.fill((0, 0, 0, 160))

        # 텍스트 배치
        y_offset = 4
        info_box.blit(name_surf, (8, y_offset))
        y_offset += name_surf.get_height() + (line_spacing if status_surfs else 0)
        for i, surf in enumerate(status_surfs):
            info_box.blit(surf, (8, y_offset))
            y_offset += current_font_height
            if i < len(status_surfs) -1:
                 y_offset += line_spacing

        # 화면에 그리기
        self.screen.blit(info_box, (box_x, box_y))

    def _draw_ui_panel(self):
        """UI 패널 그리기"""
        panel_surf = pygame.Surface((self.drawer.ui_rect.width, self.drawer.ui_rect.height))
        color_top = (170, 170, 210)
        color_bottom = (130, 130, 180)
        
        # 그라데이션 배경
        for y in range(self.drawer.ui_rect.height):
            alpha = y / float(self.drawer.ui_rect.height)
            rr = int(color_top[0] * (1 - alpha) + color_bottom[0] * alpha)
            gg = int(color_top[1] * (1 - alpha) + color_bottom[1] * alpha)
            bb = int(color_top[2] * (1 - alpha) + color_bottom[2] * alpha)
            pygame.draw.line(panel_surf, (rr, gg, bb), (0, y), (self.drawer.ui_rect.width, y))
        
        # 패널 그리기
        self.screen.blit(panel_surf, (self.drawer.ui_rect.x, self.drawer.ui_rect.y))
        pygame.draw.rect(self.screen, (50, 50, 50), self.drawer.ui_rect, 2, border_radius=10)
        
        # 버튼 그리기
        for b in self.drawer.buttons:
            b.draw(self.screen, self.font)
    
    def _draw_power_status(self):
        """전력 공급 상황 표시 (화면 하단 개선 버전)"""
        flow_val = self.simulator.calc_total_flow()
        dem = self.simulator.city.total_demand()
        
        blackout_buildings = []
        affected_demand = 0
        for b in self.simulator.city.buildings:
            if not b.removed and b.blackout:
                blackout_buildings.append(b)
                affected_demand += abs(b.base_supply)

        current_status_text = ""
        status_color = (0, 0, 0)
        icon = ""
        blink = False
        
        panel_height = 120
        panel_y_position = self.height - panel_height - 20 # 하단에서 20px 위
        panel_rect = pygame.Rect(20, panel_y_position, self.width - self.drawer.ui_rect.width - 40, panel_height)

        if blackout_buildings or flow_val + 1e-9 < dem:
            shortage = dem - flow_val if dem > 0 else 0 # 수요가 0일때 음수 부족량 방지
            shortage_percent = (shortage / dem * 100) if dem > 1e-9 else 0
            
            blackout_info = ""
            if blackout_buildings:
                blackout_info = f" | 정전: {len(blackout_buildings)}곳 (피해규모: {affected_demand:.1f})"

            if len(blackout_buildings) > 0 or shortage_percent > 50: # 50% 이상 부족 또는 정전 발생 시
                status_color = (220, 50, 50) # 진한 빨강
                icon = "⚠"
                current_status_text = f"전력 위기! 공급 {flow_val:.1f} < 수요 {dem:.1f} (부족률 {shortage_percent:.1f}%){blackout_info}"
                blink = True
                if shortage_percent > 30 or blackout_buildings: # 부가 메시지 조건은 유지
                    additional_message = "즉시 조치가 필요합니다!"
            elif shortage_percent > 20: # 20% ~ 50% 부족
                status_color = (255, 130, 0) # 주황색
                icon = "!"
                current_status_text = f"전력 부족. 공급 {flow_val:.1f} < 수요 {dem:.1f} (부족률 {shortage_percent:.1f}%){blackout_info}"
                blink = (pygame.time.get_ticks() // 700) % 2 # 약간 느린 깜빡임
            elif shortage_percent > 0: # 0% ~ 20% 부족
                status_color = (255, 200, 0) # 노란색
                icon = "!"
                current_status_text = f"경미한 전력 부족. 공급 {flow_val:.1f} < 수요 {dem:.1f} (부족률 {shortage_percent:.1f}%)"
            else: # flow_val < dem 이지만 shortage_percent가 0인 경우 (매우 작은 차이)
                status_color = (50, 180, 50) # 녹색
                icon = "✔"
                current_status_text = f"전력 안정. 공급 {flow_val:.1f} ≈ 수요 {dem:.1f}"

        else:
            status_color = (50, 180, 50) # 녹색
            icon = "✔"
            current_status_text = f"전력 공급 안정. 공급 {flow_val:.1f} / 수요 {dem:.1f}"

        # 깜빡임 효과 적용
        if blink and (pygame.time.get_ticks() // 500) % 2:
            # 깜빡일 때는 내용을 안그리거나, 투명도를 조절할 수 있음. 여기서는 그냥 건너뛰어 숨김
            return

        # 배경 패널 그리기
        bg_surface = pygame.Surface((panel_rect.width, panel_rect.height), pygame.SRCALPHA)
        bg_surface.fill((30, 30, 40, 200)) # 반투명 어두운 배경
        pygame.draw.rect(bg_surface, status_color, (0,0,panel_rect.width, 5), border_top_left_radius=10, border_top_right_radius=10) # 상단 상태 바
        self.screen.blit(bg_surface, panel_rect.topleft)
        pygame.draw.rect(self.screen, (100,100,120, 220), panel_rect, 2, border_radius=10) # 테두리
        
        # 아이콘 + 상태 텍스트
        if icon:
            icon_surf = self.big_font.render(icon, True, status_color)
            icon_rect = icon_surf.get_rect(left=panel_rect.left + 20, centery=panel_rect.centery - 15)
            self.screen.blit(icon_surf, icon_rect)
            text_start_x = icon_rect.right + 15
        else:
            text_start_x = panel_rect.left + 20

        status_surf = self.font.render(current_status_text, True, (230, 230, 240)) # 밝은 텍스트 색상
        status_rect = status_surf.get_rect(left=text_start_x, centery=panel_rect.centery - 15)
        self.screen.blit(status_surf, status_rect)
        
        # 추가 메시지 (필요시)
        if 'additional_message' in locals() and additional_message:
            add_surf = self.small_font.render(additional_message, True, (255,100,100))
            add_rect = add_surf.get_rect(left=text_start_x, centery=panel_rect.centery + 20)
            self.screen.blit(add_surf, add_rect)
            
    def _draw_mode_info(self):
        """모드 및 예산 정보 표시"""
        # 현재 모드 표시
        mode_txt = f"모드: {self.drawer.add_mode}"
        ms = self.font.render(mode_txt, True, (0, 0, 0))
        self.screen.blit(ms, (self.width - self.drawer.panel_width + 20, self.height - 120))
        
        # 예산 정보 표시 (자금 -> 예산으로 통일)
        bd_txt = f"예산: {self.simulator.budget:.1f}"
        bs = self.font.render(bd_txt, True, (0, 0, 100))
        self.screen.blit(bs, (self.width - self.drawer.panel_width + 20, self.height - 60))
    
    def _draw_time_weather(self):
        """시간 및 날씨 정보 표시"""
        # 시간, 요일, 계절 정보 가져오기
        current_time = self.simulator.simTime
        wday_kr = ["월", "화", "수", "목", "금", "토", "일"][current_time.weekday()]
        time_str = f"{current_time.year}-{current_time.month:02d}-{current_time.day:02d} {current_time.hour:02d}:{current_time.minute:02d}"
        season = self.simulator.get_current_season()
        
        # 날씨 아이콘 매핑
        icon_map = {
            "맑음": "☀",
            "흐림": "☁",
            "비": "🌧",
            "눈": "❄"
        }
        wicon = icon_map.get(self.simulator.weather_system.current_weather, "☀")
        
        # 시간 정보 표시
        kr_time = f"{time_str} ({wday_kr}) [{season}] {wicon}"
        ts = self.font.render(f"시간: {kr_time}", True, (0, 0, 0))
        shadow_ts = self.font.render(f"시간: {kr_time}", True, (255, 255, 255))
        self.screen.blit(shadow_ts, (11, 11))
        self.screen.blit(ts, (10, 10))
        
        # 날씨 정보 표시
        weather_info = (
            f"날씨: {self.simulator.weather_system.current_weather}\n"
            f"기온: {self.simulator.weather_system.current_temperature:.1f}°C\n"
            f"습도: {self.simulator.weather_system.humidity:.1f}%\n"
            f"구름: {self.simulator.weather_system.cloud_factor*100:.0f}%\n"
            f"태양광: {self.simulator.weather_system.get_potential_solar_generation_ratio()*100:.2f}%"
        )
        
        # 멀티라인 텍스트 렌더링
        y_offset = 40
        for line in weather_info.split('\n'):
            ws = self.font.render(line, True, (0, 0, 0))
            shadow_ws = self.font.render(line, True, (255, 255, 255))
            self.screen.blit(shadow_ws, (11, y_offset + 1))
            self.screen.blit(ws, (10, y_offset))
            y_offset += 30

    def draw_help_overlay(self):
        """도움말 오버레이 표시"""
        w = self.drawer.panel_width + 100
        h = self.height // 2 + 160
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((240, 240, 255, 220))
        self.screen.blit(overlay, (10, 10))
        
        # 도움말 텍스트
        lines = [
            "[도움말 - F1]",
            "ESC: 종료",
            "R: 전체 복원",
            "",
            "마우스 왼드래그 => 건물 이동",
            "오른클릭 => 건물/송전선 컨텍스트 메뉴",
            "휠 => 줌",
            "",
            "수요(아파트)는 시간대/날씨에 따라 변동",
            "발전소(>0)는 기본 공급 유지",
            "정전은 공급 부족 시 발생",
            "",
            "시나리오 목록 => 불러오기",
            "상태 저장 => output_save.json",
            "AI 업그레이드 => 용량 or 발전량 증가"
        ]
        
        fx = 25
        fy = 25
        for i, ln in enumerate(lines):
            shadow = self.font.render(ln, True, (0, 0, 0, 120))
            text = self.font.render(ln, True, (0, 0, 0))
            self.screen.blit(shadow, (fx + 1, fy + 1 + i * 22))
            self.screen.blit(text, (fx, fy + i * 22))
    
    def draw_scenario_list(self):
        """시나리오 목록 표시"""
        w = 800
        h = 800
        left = (self.width - w) // 2
        top = 50
        panel_rect = pygame.Rect(left, top, w, h)
        shadow_rect = panel_rect.copy()
        shadow_rect.x += 5
        shadow_rect.y += 5
        
        # 배경 그리기
        pygame.draw.rect(self.screen, (180, 180, 200), shadow_rect, border_radius=10)
        pygame.draw.rect(self.screen, (240, 240, 255), panel_rect, border_radius=10)
        pygame.draw.rect(self.screen, (50, 50, 50), panel_rect, 2, border_radius=10)
        
        # 제목 표시
        txt = self.big_font.render("시나리오 목록", True, (0, 0, 0))
        txt_rect = txt.get_rect(centerx=panel_rect.centerx, top=top + 20)
        self.screen.blit(txt, txt_rect)
        
        # 시나리오 목록 표시
        item_h = 80
        item_gap = 12
        item_padding_y = 15 # 항목 내부 상하단 여백
        text_gap = 6       # 이름과 설명 사이 간격
        button_margin_x = 20 # 버튼 좌우 여백
        text_margin_x = 20   # 텍스트 좌우 여백

        ycur = top + 80 - self.drawer.scenario_scroll
        # 시나리오 목록을 최대 7개까지만 표시
        for i, scen in enumerate(self.simulator.scenarios[:7]):
            # 목록 항목 배경
            irect = pygame.Rect(left + 30, ycur, w - 60, item_h)
            pygame.draw.rect(self.screen, (210, 210, 230), irect, border_radius=8)
            pygame.draw.rect(self.screen, (100, 100, 130), irect, 1, border_radius=8)
            
            # 불러오기 버튼 정의 (위치 계산을 위해 먼저 정의)
            btn_w = 100
            btn_h = 32
            load_btn_rect = pygame.Rect(irect.right - btn_w - button_margin_x, 
                                      irect.centery - btn_h // 2, 
                                      btn_w, btn_h)

            # 시나리오 이름 (폰트 크기 조정: self.small_font 사용)
            nm_text = f"{i}) {scen['name']}"
            # 이름도 너무 길면 잘라낼 수 있지만, 폰트 크기를 줄였으므로 우선 그대로 둠
            # 필요하다면 이름에도 _truncate_text 적용 가능
            nm_s = self.small_font.render(nm_text, True, (0, 0, 0)) # self.scenario_name_font -> self.small_font
            name_render_rect = nm_s.get_rect(left=irect.x + text_margin_x, top=irect.y + item_padding_y)
            self.screen.blit(nm_s, name_render_rect)
            
            # 시나리오 설명
            desc_text = scen.get("desc", "(설명 없음)")
            # 사용 가능한 너비 계산: 항목 전체 너비 - 좌우 텍스트 여백 - 버튼 너비 - 버튼 좌우 여백
            fudge_factor = 40 # 경험적으로 찾은 값, 필요시 조정
            available_desc_width = irect.width - (text_margin_x * 2) - load_btn_rect.width - (button_margin_x * 1) - fudge_factor
            
            truncated_desc = self._truncate_text(desc_text, self.small_font, available_desc_width)
            desc_s = self.small_font.render(truncated_desc, True, (70, 70, 70))
            # 이름 바로 아래에 설명 배치
            desc_render_rect = desc_s.get_rect(left=irect.x + text_margin_x, top=name_render_rect.bottom + text_gap)
            self.screen.blit(desc_s, desc_render_rect)
            
            # 불러오기 버튼 그리기
            pygame.draw.rect(self.screen, (180, 255, 180), load_btn_rect, border_radius=6)
            pygame.draw.rect(self.screen, (50, 100, 50), load_btn_rect, 1, border_radius=6)
            load_s = self.small_font.render("불러오기", True, (0, 0, 0))
            lb_tr = load_s.get_rect(center=load_btn_rect.center)
            self.screen.blit(load_s, lb_tr)
            
            ycur += item_h + item_gap
        
        # 스크롤바 로직은 이제 필요 없음 (최대 7개만 표시하므로)
        # total_height = (item_h + item_gap) * len(self.simulator.scenarios[:7]) # 어차피 7개 이하
        # if total_height > h: # 이 조건은 거의 만족하지 않거나, 만족해도 스크롤바가 매우 짧아 의미 없을 수 있음
        #     bar_height = h * h / total_height
        #     bar_pos = (self.drawer.scenario_scroll / total_height) * (h - bar_height)
        #     scroll_rect = pygame.Rect(panel_rect.right - 15, top + bar_pos, 10, bar_height)
        #     pygame.draw.rect(self.screen, (150, 150, 150), scroll_rect, border_radius=5)
    
    def draw_ai_upgrade_panel(self):
        """AI 업그레이드 패널을 화면에 표시합니다."""
        panel_width = 800
        panel_height = 800 # 높이 증가 (기존 750 -> 800)
        panel_x = (self.width - panel_width) // 2
        panel_y = (self.height - panel_height) // 2
        
        # 반투명 오버레이 추가 (전체 화면 어둡게)
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))  # 어두운 반투명 배경
        self.screen.blit(overlay, (0, 0))
        
        # 패널 배경 (그라데이션 효과 추가)
        panel_surface = pygame.Surface((panel_width, panel_height))
        for y_loop in range(panel_height): # y 변수명 변경 (함수 내 다른 y_offset과 충돌 방지)
            alpha = y_loop / panel_height
            color = (
                int(40 + 10 * alpha),
                int(40 + 15 * alpha),
                int(60 + 20 * alpha)
            )
            pygame.draw.line(panel_surface, color, (0, y_loop), (panel_width, y_loop))
        
        # 패널 테두리
        pygame.draw.rect(panel_surface, (100, 100, 160), (0, 0, panel_width, panel_height), 3, border_radius=10)
        
        # 빛나는 효과 (상단)
        glow_height = 80
        for y_loop in range(glow_height): # y 변수명 변경
            alpha_glow = 100 - (y_loop / glow_height * 100) # alpha 변수명 변경 (함수 내 다른 alpha와 충돌 방지)
            glow_color = (80, 90, 180, int(alpha_glow))
            pygame.draw.line(panel_surface, glow_color, (10, y_loop+5), (panel_width-10, y_loop+5), 2)
        
        self.screen.blit(panel_surface, (panel_x, panel_y))
        
        # 제목
        title_font = self.font
        title_text = "AI 전력망 최적화 시스템"
        title_surface = title_font.render(title_text, True, (220, 220, 250))
        title_rect = title_surface.get_rect(centerx=panel_x + panel_width//2, top=panel_y + 20)
        self.screen.blit(title_surface, title_rect)
        
        # 현재 전력망 상태 분석 결과
        analysis_results = getattr(self.drawer, 'current_grid_analysis_results', None)
        if analysis_results:
            overall_sev = analysis_results.get('overall_severity', 0)
            summary_text = analysis_results.get('summary', '전력망 상태 분석 중...')
            
            summary_color_val = (100, 255, 100)
            status_text = "정상"
            if overall_sev >= 0.9: 
                summary_color_val = (255, 100, 100)
                status_text = "심각"
            elif overall_sev >= 0.7: 
                summary_color_val = (255, 150, 50)
                status_text = "경고"
            elif overall_sev >= 0.4: 
                summary_color_val = (255, 220, 50)
                status_text = "주의"
                
            status_rect = pygame.Rect(panel_x + panel_width - 120, panel_y + 30, 100, 40)
            status_surface = pygame.Surface((100, 40))
            status_surface.fill(summary_color_val)
            pygame.draw.rect(status_surface, (255, 255, 255), (0, 0, 100, 40), 2)
            self.screen.blit(status_surface, status_rect)
            
            status_font = self.font
            status_label = status_font.render(status_text, True, (0, 0, 0))
            status_label_rect = status_label.get_rect(center=status_rect.center)
            self.screen.blit(status_label, status_label_rect)
            
            y_offset = panel_y + 80
            
            analysis_header_font = self.font
            analysis_header = analysis_header_font.render("전력망 분석 결과", True, (200, 200, 255))
            analysis_header_rect = analysis_header.get_rect(centerx=panel_x + panel_width//2, top=y_offset)
            self.screen.blit(analysis_header, analysis_header_rect)
            y_offset += analysis_header.get_height() + 5
            
            pygame.draw.line(self.screen, (150, 150, 200), 
                             (panel_x + 50, y_offset), 
                             (panel_x + panel_width - 50, y_offset), 2)
            y_offset += 10
            
            gauge_width = panel_width - 100
            gauge_height = 20
            pygame.draw.rect(self.screen, (80, 80, 100), 
                             (panel_x + 50, y_offset, gauge_width, gauge_height), 0, border_radius=5)
            
            filled_width = int(gauge_width * overall_sev)
            for x_loop in range(filled_width):
                pos = x_loop / gauge_width
                gauge_color = (0,0,0)
                if pos < 0.5: 
                    gauge_color = (int(510 * pos), 255, 0)
                else: 
                    gauge_color = (255, int(255 * (2 - 2 * pos)), 0)
                pygame.draw.line(self.screen, gauge_color, 
                                (panel_x + 50 + x_loop, y_offset), 
                                (panel_x + 50 + x_loop, y_offset + gauge_height), 1)
            
            pygame.draw.rect(self.screen, (200, 200, 200), 
                             (panel_x + 50, y_offset, gauge_width, gauge_height), 2, border_radius=5)
            
            severity_text = f"{overall_sev*100:.1f}%"
            severity_font = self.small_font
            severity_surf = severity_font.render(severity_text, True, (255, 255, 255))
            severity_rect_midright_x = panel_x + 50 + filled_width - 5 if filled_width > 5 else panel_x + 50 + 5 
            severity_rect = severity_surf.get_rect(midright=(severity_rect_midright_x, y_offset + gauge_height//2))
            self.screen.blit(severity_surf, severity_rect)
            
            y_offset += gauge_height + 10
            
            summary_surface = self.font.render(self._truncate_text(summary_text, self.font, panel_width - 60), True, summary_color_val)
            summary_rect = summary_surface.get_rect(centerx=panel_x + panel_width // 2, top=y_offset)
            self.screen.blit(summary_surface, summary_rect)
            y_offset += summary_surface.get_height() + 10
            
            problems = analysis_results.get('problems', [])
            if problems:
                problem_font = self.font
                
                for i, problem in enumerate(problems[:3]):
                    problem_type = problem.get('type', '')
                    problem_severity = problem.get('severity', 0)
                    
                    problem_color_val = (200,200,200)
                    icon_text = "•"
                    if problem_type == 'overloaded_line':
                        problem_color_val = (255, 100, 100) if problem_severity > 0.7 else (255, 180, 50)
                        icon_text = "⚡"
                    elif problem_type == 'blackout_buildings':
                        problem_color_val = (255, 50, 50)
                        icon_text = "⚠️"
                    elif problem_type == 'low_voltage':
                        problem_color_val = (255, 150, 0)
                        icon_text = "↓"
                    elif problem_type == 'overall_shortage':
                         problem_color_val = (255, 100, 50) if problem_severity > 0.6 else (255, 180, 80)
                         icon_text = "📉"
                    elif problem_type == 'low_supply_capacity_margin':
                         problem_color_val = (255, 165, 0)
                         icon_text = "📊"
                    elif problem_type == 'inefficient_producer':
                         problem_color_val = (200, 200, 100)
                         icon_text = "⚙️"

                    icon_surf = problem_font.render(icon_text, True, problem_color_val)
                    icon_rect = icon_surf.get_rect(left=panel_x + 60, top=y_offset)
                    self.screen.blit(icon_surf, icon_rect)
                    
                    description = problem.get('description', '알 수 없는 문제')
                    desc_surf = problem_font.render(
                        self._truncate_text(description, problem_font, panel_width - 140), 
                        True, problem_color_val
                    )
                    desc_rect = desc_surf.get_rect(left=panel_x + 90, top=y_offset)
                    self.screen.blit(desc_surf, desc_rect)
                    
                    y_offset += desc_surf.get_height() + 5
                
                if len(problems) > 3:
                    more_text = f"+ {len(problems) - 3}개 더 많은 문제점..."
                    more_surf = self.small_font.render(more_text, True, (180, 180, 200))
                    more_rect = more_surf.get_rect(centerx=panel_x + panel_width//2, top=y_offset)
                    self.screen.blit(more_surf, more_rect)
                    y_offset += more_surf.get_height() + 8
            
            pygame.draw.line(self.screen, (150, 150, 200), 
                            (panel_x + 50, y_offset), 
                            (panel_x + panel_width - 50, y_offset), 2)
            y_offset += 10
            
            upgrade_header_font = self.font
            upgrade_header = upgrade_header_font.render("추천 업그레이드 옵션", True, (200, 200, 255))
            upgrade_header_rect = upgrade_header.get_rect(centerx=panel_x + panel_width//2, top=y_offset)
            self.screen.blit(upgrade_header, upgrade_header_rect)
            y_offset += upgrade_header.get_height() + 8
            
            budget_font = self.font
            budget_text = f"현재 예산: {self.simulator.budget:.1f}"
            budget_surf = budget_font.render(budget_text, True, (150, 255, 150))
            budget_rect = budget_surf.get_rect(centerx=panel_x + panel_width//2, top=y_offset)
            self.screen.blit(budget_surf, budget_rect)
            y_offset += budget_surf.get_height() + 5 # 여백 10 -> 5
            
            self.drawer.ai_panel_options_start_y = y_offset
        
        if hasattr(self.drawer, 'ai_upgrade_option_buttons'):
            for button in self.drawer.ai_upgrade_option_buttons:
                button.draw(self.screen, self.font)
        
        close_button_size = 30
        close_button_rect = pygame.Rect(panel_x + panel_width - close_button_size - 10, panel_y + 10, close_button_size, close_button_size)
        pygame.draw.rect(self.screen, (150, 70, 70), close_button_rect, 0, border_radius=15)
        pygame.draw.rect(self.screen, (220, 220, 220), close_button_rect, 2, border_radius=15)
        
        pygame.draw.rect(self.screen, (150, 70, 70), close_button_rect, 0, border_radius=15) # 닫기 버튼 색상 변경
        pygame.draw.rect(self.screen, (220, 220, 220), close_button_rect, 2, border_radius=15) # 닫기 버튼 테두리 색상 변경
        
        # X 표시
        pygame.draw.line(self.screen, (255, 255, 255), 
                         (close_button_rect.left + 8, close_button_rect.top + 8), 
                         (close_button_rect.right - 8, close_button_rect.bottom - 8), 3) # X 표시 두께 증가
        pygame.draw.line(self.screen, (255, 255, 255), 
                         (close_button_rect.left + 8, close_button_rect.bottom - 8), 
                         (close_button_rect.right - 8, close_button_rect.top + 8), 3) # X 표시 두께 증가

    def draw_tooltip(self):
        """호버 상태의 건물이나 송전선에 대한 툴팁 표시"""
        if not (self.drawer.hover_bldg or self.drawer.hover_line):
            return
        
        lines = []
        if self.drawer.hover_bldg and not self.drawer.hover_bldg.removed:
            # 건물 툴팁
            b = self.drawer.hover_bldg
            lines.append(("● " + b.get_type_str() + f" {b.idx}", (255, 255, 200)))
            
            # 건물 상세 정보 추가
            if hasattr(b, 'get_detailed_info'):
                detailed_info = b.get_detailed_info()
                # 추가 색상 매핑 (키워드에 따라 다른 색상 적용)
                for info in detailed_info:
                    color = (200, 255, 200)  # 기본 색상
                    
                    # 특정 키워드에 따른 색상 변경
                    if "정전" in info:
                        color = (255, 100, 100)
                    elif "태양광" in info:
                        color = (255, 255, 150)
                    elif "부족" in info:
                        color = (255, 150, 150)
                    elif "배터리" in info:
                        color = (150, 200, 255)
                    
                    lines.append(("  " + info, color))
            else:
                # 기존 방식의 정보 표시 (get_detailed_info가 없는 경우)
                if b.base_supply < 0:
                    demand = abs(b.base_supply)
                    lines.append((f"  필요 전력: {demand:.1f}", (200, 255, 200)))
                    if b.solar_capacity > 0:
                        curr_solar = b.current_supply + demand
                        lines.append((f"  자체 발전: {curr_solar:.1f}", (255, 255, 150)))
                    total_supply = b.current_supply + demand
                    shortage = demand - total_supply
                    if shortage > 1e-9:
                        shortage_ratio = shortage / demand * 100
                        if shortage_ratio < 10:
                            color = (200, 255, 200)
                        elif shortage_ratio < 30:
                            color = (255, 255, 150)
                        else:
                            color = (255, 150, 150)
                        lines.append((f"  부족: {shortage:.1f}", color))
                        lines.append((f"  부족률: {shortage_ratio:.1f}%", color))
                    else:
                        lines.append(("  정상 공급", (150, 255, 150)))
                else:
                    if b.base_supply > 0:
                        lines.append((f"  기본 발전: {b.base_supply:.1f}", (200, 255, 200)))
                    if b.solar_capacity > 0:
                        curr_solar = b.current_supply - b.base_supply
                        lines.append((f"  태양광 발전: {curr_solar:.1f}", (255, 255, 150)))
                    if b.base_supply > 0:
                        lines.append((f"  송전량: {b.transmitted_power:.1f}", (200, 255, 200)))
                    else:
                        lines.append((f"  총 발전량: {b.current_supply:.1f}", (200, 255, 200)))
                if b.blackout:
                    lines.append(("  ⚠ 정전!", (255, 100, 100)))
        
        elif self.drawer.hover_line and not self.drawer.hover_line.removed:
            # 송전선 툴팁
            pl = self.drawer.hover_line
            cap = pl.capacity
            f = pl.flow
            usage = 0 if cap < 1e-9 else abs(f) / cap
            lines.append(("● 송전선 정보", (255, 255, 200)))
            lines.append((f"  연결: {pl.u} → {pl.v}", (220, 220, 255)))
            lines.append((f"  최대 용량: {cap:.1f}", (200, 255, 200)))
            lines.append((f"  현재 흐름: {f:+.1f}", (200, 255, 200)))
            usage_color = (150, 255, 150) if usage < 0.5 else (255, 255, 150) if usage < 0.8 else (255, 150, 150)
            lines.append((f"  사용률: {usage*100:.1f}%", usage_color))
            
            # 과부하 경고
            if usage > 0.8:
                lines.append(("  ⚠ 과부하 위험!", (255, 100, 100)))
            
            # 비용 정보
            lines.append((f"  설치 비용: {pl.cost:.1f}", (200, 200, 255)))
            
            # 현재 상태
            if usage < 0.3:
                status = "여유"
                status_color = (150, 255, 150)
            elif usage < 0.7:
                status = "정상"
                status_color = (220, 220, 150)
            elif usage < 0.9:
                status = "부하"
                status_color = (255, 200, 100)
            else:
                status = "위험"
                status_color = (255, 100, 100)
            lines.append((f"  상태: {status}", status_color))
        
        if not lines:
            return
        
        # 툴팁 크기 계산
        margin = 8
        padding = 10
        line_padding = 2
        lineh = 24
        
        w = max(self.small_font.size(text)[0] for text, _ in lines) + padding * 2
        h = len(lines) * lineh + (len(lines) - 1) * line_padding + padding * 2
        
        # 툴팁 위치 조정
        mx, my = pygame.mouse.get_pos()
        tooltip_x = mx + margin
        tooltip_y = my + margin
        if tooltip_x + w > self.width - margin:
            tooltip_x = mx - w - margin
        if tooltip_y + h > self.height - margin:
            tooltip_y = my - h - margin
        
        # 그림자 효과
        shadow_offset = 3
        shadow = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(shadow, (0, 0, 0, 60), shadow.get_rect(), border_radius=8)
        self.screen.blit(shadow, (tooltip_x + shadow_offset, tooltip_y + shadow_offset))
        
        # 배경 그라데이션
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        gradient_top = (60, 60, 80, 255)
        gradient_bottom = (40, 40, 60, 255)
        for y in range(h):
            alpha = y / h
            color = [int(gradient_top[i] * (1 - alpha) + gradient_bottom[i] * alpha) for i in range(4)]
            pygame.draw.line(surf, color, (0, y), (w, y))
        
        # 테두리
        pygame.draw.rect(surf, (255, 255, 255, 50), surf.get_rect(), border_radius=8)
        
        # 텍스트 그리기
        y = padding
        for text, color in lines:
            txt_surf = self.small_font.render(text, True, color)
            txt_rect = txt_surf.get_rect(x=padding, y=y)
            surf.blit(txt_surf, txt_rect)
            y += lineh + line_padding
        
        # 화면에 그리기
        self.screen.blit(surf, (tooltip_x, tooltip_y)) 